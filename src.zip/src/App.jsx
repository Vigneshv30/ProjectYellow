import { useState } from 'react'

import Home from './layout/Home'
function App() {

  return (
    <>
    <div className='w-100'>
     <Home/>
    </div>
    </>
  )
}

export default App
