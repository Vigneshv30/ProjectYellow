import * as React from 'react';
import axios from 'axios';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogTitle from '@mui/material/DialogTitle';

export default function StudentTable() {
  const [rows, setRows] = React.useState([]);
  const [open, setOpen] = React.useState(false);
  const [currentRow, setCurrentRow] = React.useState(null);
  const [isAdding, setIsAdding] = React.useState(false);

  React.useEffect(() => {
    axios.get('https://jsonplaceholder.typicode.com/users')
      .then((response) => {
        const dataWithAvatars = response.data.map(user => ({
          ...user,
          avatar: `https://robohash.org/${user.username}.png`
        }));
        setRows(dataWithAvatars);
      })
      .catch((error) => {
        console.error('There was an error fetching the data!', error);
      });
  }, []);

  const handleDelete = (id) => {
    axios.delete(`https://jsonplaceholder.typicode.com/users/${id}`)
      .then((response) => {
        if (response.status === 200) {
          setRows(rows.filter(row => row.id !== id));
        } else {
          console.error('Failed to delete the user');
        }
      })
      .catch((error) => {
        console.error('There was an error deleting the user!', error);
      });
  };

  const handleClickOpen = (row) => {
    setCurrentRow(row);
    setOpen(true);
    setIsAdding(false);
  };

  const handleAddStudent = () => {
    setCurrentRow({
      name: '',
      username: '',
      email: '',
      phone: '',
      website: '',
    });
    setOpen(true);
    setIsAdding(true);
  };

  const handleClose = () => {
    setOpen(false);
    setCurrentRow(null);
    setIsAdding(false);
  };

  const handleSave = () => {
    if (isAdding) {
      axios.post('https://jsonplaceholder.typicode.com/users', currentRow)
        .then((response) => {
          if (response.status === 201) {
            setRows([...rows, { ...response.data, avatar: `https://robohash.org/${response.data.username}.png` }]);
            handleClose();
          } else {
            console.error('Failed to add the user');
          }
        })
        .catch((error) => {
          console.error('There was an error adding the user!', error);
        });
    } else {
      axios.put(`https://jsonplaceholder.typicode.com/users/${currentRow.id}`, currentRow)
        .then((response) => {
          if (response.status === 200) {
            setRows(rows.map(row => (row.id === currentRow.id ? currentRow : row)));
            handleClose();
          } else {
            console.error('Failed to update the user');
          }
        })
        .catch((error) => {
          console.error('There was an error updating the user!', error);
        });
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCurrentRow({ ...currentRow, [name]: value });
  };

  return (
    <>
    <div className='d-flex justify-content-end '>
      <Button variant="contained" color="primary" onClick={handleAddStudent}>
        Add Student
      </Button>
    </div>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Avatar</TableCell>
              <TableCell>Name</TableCell>
              <TableCell align="right">Username</TableCell>
              <TableCell align="right">Email</TableCell>
              <TableCell align="right">Phone</TableCell>
              <TableCell align="right">Website</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow
                key={row.id}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
              >
                <TableCell>
                  <Avatar alt={row.name} src={row.avatar} />
                </TableCell>
                <TableCell component="th" scope="row">
                  {row.name}
                </TableCell>
                <TableCell align="right">{row.username}</TableCell>
                <TableCell align="right">{row.email}</TableCell>
                <TableCell align="right">{row.phone}</TableCell>
                <TableCell align="right">{row.website}</TableCell>
                <TableCell align="right" sx={{ display: 'flex',gap: '30px' }}>
                  <Button variant="contained" color="secondary" onClick={() => handleDelete(row.id)}>Delete</Button>
                  <Button variant="contained" color="primary" onClick={() => handleClickOpen(row)}>Edit</Button>

                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>

        {currentRow && (
          <Dialog open={open} onClose={handleClose}>
            <DialogTitle>{isAdding ? 'Add Student' : 'Edit Details'}</DialogTitle>
            <DialogContent>
              <TextField
                autoFocus
                margin="dense"
                name="name"
                label="Name"
                type="text"
                fullWidth
                value={currentRow.name}
                onChange={handleChange}
              />
              <TextField
                margin="dense"
                name="username"
                label="Username"
                type="text"
                fullWidth
                value={currentRow.username}
                onChange={handleChange}
              />
              <TextField
                margin="dense"
                name="email"
                label="Email"
                type="email"
                fullWidth
                value={currentRow.email}
                onChange={handleChange}
              />
              <TextField
                margin="dense"
                name="phone"
                label="Phone"
                type="text"
                fullWidth
                value={currentRow.phone}
                onChange={handleChange}
              />
              <TextField
                margin="dense"
                name="website"
                label="Website"
                type="text"
                fullWidth
                value={currentRow.website}
                onChange={handleChange}
              />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleClose} color="primary">Cancel</Button>
              <Button onClick={handleSave} color="primary">{isAdding ? 'Add' : 'Save'}</Button>
            </DialogActions>
          </Dialog>
        )}
      </TableContainer>
    </>
  );
}