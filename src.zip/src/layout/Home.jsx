import React from 'react'
import Grid from '@mui/material/Grid';
import Avatar from '@mui/material/Avatar';
import Typography from '@mui/material/Typography';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import StudentTable from '../components/StudentTable';



const Home = () => {
  return (
    <div className='w-100 d-flex'>
        <aside className='p-3 bg-black text-white ' style={{width: '20%'}}>
      <Grid container spacing={2} sx={{
        justifyContent: 'center',
        alignItems: 'end',
      }}>
        <Grid item xs={2}>
        <Avatar className='vv mr-2'
        alt="Remy Sharp"
        src='https://mui.com/static/images/avatar/1.jpg' 
        sx={{ width: 56, height: 56, }}
      />
        </Grid>
        <Grid item xs={10}>
        <Typography variant="button" display="block" gutterBottom className='vickyv m-2'>
         Vicky
        </Typography>
        <Typography variant="caption" display="block" gutterBottom className='vickyv m-2'>
         Admin
        </Typography>
        </Grid>
      </Grid>
        </aside>
        <main className='p-3' style={{width: '80%'}}>
            {/* App bar */}
    <header>
        <AppBar position="static">
        <Toolbar>
        <Typography variant="button" display="block" gutterBottom>
         Students
        </Typography>
        </Toolbar>
        </AppBar>
    </header>
    <div className='p-5'>
     {/* Table    */}  
      <StudentTable/>
      </div>
    </main>
    </div>
  )
}

export default Home